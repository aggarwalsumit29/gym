-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 03, 2018 at 03:26 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `beast_gym`
--
CREATE DATABASE IF NOT EXISTS `beast_gym` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `beast_gym`;

-- --------------------------------------------------------

--
-- Table structure for table `custo_detaildiet_planenquiry_formequipmemtsexercise_planfacilitysubscriptiontrainer_detailuser_details`
--
-- in use(#1059 - Identifier name 'custo_detaildiet_planenquiry_formequipmemtsexercise_planfacilitysubscriptiontrainer_detailuser_detai' is too long)
-- Error reading data: (#1059 - Identifier name 'custo_detaildiet_planenquiry_formequipmemtsexercise_planfacilitysubscriptiontrainer_detailuser_detai' is too long)

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
